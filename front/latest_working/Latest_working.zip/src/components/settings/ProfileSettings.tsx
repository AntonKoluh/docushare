const ProfileSettings = () => {
  return <h1>WIP</h1>;
};

export default ProfileSettings;
