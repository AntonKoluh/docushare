import styles from "./LoginSpinner.module.css";

const SpinnerLogin = () => {
  return <div className={styles.spinner}></div>;
};

export default SpinnerLogin;
