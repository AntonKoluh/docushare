export default function SearchList() {
  return (
    <input
      type="text"
      name="docListSearch"
      id="docListSearch"
      className="justify-self-center w-100 h-10 bg-gray-800 rounded-4xl px-3 text-2xl"
      placeholder="search"
    />
  );
}
